package lambdas;

public class Diskothek 
{
	private TuerSteher kaya;

	public Diskothek() {
		super();
		kaya=new TuerSteher();
	}

	public TuerSteher getKaya() {
		return kaya;
	}

	public void setKaya(TuerSteher kaya) {
		this.kaya = kaya;
	}
	
	
	
	
	
	
}
