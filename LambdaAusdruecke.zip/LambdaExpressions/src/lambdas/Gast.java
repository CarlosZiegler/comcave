package lambdas;

public class Gast 
{
	private int alter;
	private String geschlecht;
	public Gast(int alter, String geschlecht) {
		super();
		this.alter = alter;
		this.geschlecht = geschlecht;
	}
	public int getAlter() {
		return alter;
	}
	public void setAlter(int alter) {
		this.alter = alter;
	}
	public String getGeschlecht() {
		return geschlecht;
	}
	public void setGeschlecht(String geschlecht) {
		this.geschlecht = geschlecht;
	}
	
	
	
	
	
	
}
