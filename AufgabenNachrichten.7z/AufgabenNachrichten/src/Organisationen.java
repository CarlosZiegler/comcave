
public abstract class Organisationen implements Iorganisationen {
	private String name;
	private String adress;
	private int umsatzsteuerID;
	
	@Override
	public String getName() {
		return name;
	}

	@Override
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String getAdress() {
		// TODO Auto-generated method stub
		return adress;
	}

	@Override
	public void setAdress(String adress) {
		this.adress = adress;
	}

	@Override
	public int getUmsatzteuerID() {
		// TODO Auto-generated method stub
		return umsatzsteuerID;
	}

	@Override
	public void setUmsatzteuerID(int umsatzsteuerID) {
		this.umsatzsteuerID = umsatzsteuerID;
		
	}
	
	
}
