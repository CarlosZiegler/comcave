
public interface Iperson {
 public String getName();
 public void setName(String name);
 public String getAdress();
 public void setAdress(String adress); 
 public int getSteuernummer();
 public void setSteuernummer(int steuernummer);
 }
