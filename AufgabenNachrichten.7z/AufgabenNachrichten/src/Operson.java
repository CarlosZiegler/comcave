
public class Operson extends Person{
 private String fachgebiet ;
 private String persongeschicht;
public String getFachgebiet() {
	return fachgebiet;
}
public void setFachgebiet(String fachgebiet) {
	this.fachgebiet = fachgebiet;
}
public String getPersongeschicht() {
	return persongeschicht;
}
public void setPersongeschicht(String persongeschicht) {
	this.persongeschicht = persongeschicht;
}
@Override
public void registrieren(Vermittler v) {
	// TODO Auto-generated method stub
	
}
 
 
}
