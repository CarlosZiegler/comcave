
public abstract class Person implements Iperson,IEmpfanger {
	private String name;
	private String adress;
	private int steuernummer;
	
	@Override
	public String getName() {
		return name;
	}

	@Override
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String getAdress() {
		// TODO Auto-generated method stub
		return adress;
	}

	@Override
	public void setAdress(String adress) {
		this.adress = adress;
	}

	@Override
	public int getSteuernummer() {
		// TODO Auto-generated method stub
		return  steuernummer;
	}

	@Override
	public void setSteuernummer(int steuernummer) {
		this.steuernummer = steuernummer;
	}
	
	
	
	
}
