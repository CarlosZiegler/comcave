
public class Firmen extends Organisationen{

	
}
