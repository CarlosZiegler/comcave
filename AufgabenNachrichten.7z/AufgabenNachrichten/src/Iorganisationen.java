
public interface Iorganisationen {
	 public String getName();
	 public void setName(String name);
	 public String getAdress();
	 public void setAdress(String adress); 
	 public int getUmsatzteuerID();
	 public void setUmsatzteuerID(int UmsatzteuerID);
	 
	 
}
