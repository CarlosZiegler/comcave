
public class Bildungseinrichtungen extends Organisationen {

}
