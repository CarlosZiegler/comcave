
public interface IEmpfanger {
	void registrieren( Vermittler v);
}
