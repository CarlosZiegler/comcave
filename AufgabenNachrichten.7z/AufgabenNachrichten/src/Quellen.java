
public abstract class Quellen implements IQuellen {
	private String name;

	@Override
	public String getName() {
		
		return name;
	}

	@Override
	public void setName(String name) {
		this.name = name;
	}
		
}
