
public class Pperson extends Person {

	@Override
	public void registrieren(Vermittler v) {
		// TODO Auto-generated method stub
		
	}
	

}
