
public class Intitutionen extends Organisationen {
 
	
	
}
