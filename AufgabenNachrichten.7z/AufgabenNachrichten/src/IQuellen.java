
public interface IQuellen {
 public String getName();
 public void setName(String name);
}
