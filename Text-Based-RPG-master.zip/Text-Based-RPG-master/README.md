#Text-Based-RPG

                                                     /   \    
                    _                        )      ((   ))     (                           
                   (@)                      /|\      ))_((     /|\    
                   |-|                     / | \    (/\|/\)   / | \                      (@)
                   | | -------------------/--|-voV---\`|'/--Vov-|--\---------------------|-|
                   |-|                         '^`   (o o)  '^`                          | |
                   | |                               `\Y/'                               |-|
                   |-|                                                                   | |
                   | |                           Text Based RPG                          |-|
                   |-|                                                                   | |
                   | |                                                                   |-|
                   |_|___________________________________________________________________| |
                   (@)              l   /\ /         ( (       \ /\   l                `\|-|
                                    l /   V           \ \       V   \ l                  (@)
                                    l/                _) )_          \I                     
                                                      `\ /'                                 
                                                        `                                

Java implementation of a text based RPG made in BlueJ 
The game is an extension of the World of Zuul project found in [Objects First with Java - A Practical Introduction using BlueJ](http://www.bluej.org/help/textbook.html)

This is my first project to learn object oriented programming during the course [IS-102](http://www.uia.no/en/studieplaner/topic/IS-102-1) at the University of Agder

![alt text](https://github.com/aleksanderj/Text-Based-RPG/blob/master/class_overview.PNG "Class overview")
*Overview of project classes*
