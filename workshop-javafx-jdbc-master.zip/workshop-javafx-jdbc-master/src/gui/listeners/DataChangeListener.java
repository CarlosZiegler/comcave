package gui.listeners;

public interface DataChangeListener {

	void onDataChanged();
}
